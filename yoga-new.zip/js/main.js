$('.bxslider').bxSlider({
 slideWidth: 600,
 pager: false
});